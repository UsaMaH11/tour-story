export default [
  
    {
      id: '1',
      image: 'https://i.pinimg.com/236x/35/cf/10/35cf10d61fe4d10c180560204be44144.jpg',
      title: 'Usama',
      Description:"Tour Guide in Naran",
      destinations:" Naran",
      Serices: {
      car:'Personal Car',
      TourType:'Private Tour',
      Duration:"4 Nights 3 days",
      TicketsInfo:'Not Included',
      Languages:'English , Urdu , Hindko , Pashto'
       },
       TourDescription:{
           Day1:"To secure a challenging position in a reputed Organization that provides an opportunity to grow and excel in the field of Mobile Application development  and using best practices to achieve organizational targets.",
           Day2:"To secure a challenging position in a reputed Organization that provides an opportunity to grow and excel in the field of Mobile Application development  and using best practices to achieve organizational targets.",
           Day3:"To secure a challenging position in a reputed Organization that provides an opportunity to grow and excel in the field of Mobile Application development  and using best practices to achieve organizational targets."
       },
    },    
  ];