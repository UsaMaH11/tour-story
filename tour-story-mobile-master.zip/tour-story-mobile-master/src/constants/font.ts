export const font = {
  one: {
    // bold: 'NotoSans-Bold',
    // regular: 'NotoSans-Regular',
    // medium: 'Roboto-Medium',
    // semiBold: 'Roboto-Medium',
    // bold: 'Roboto-Bold',
  },
  two: {
    // bold: 'Roboto-Bold',
    // regular: 'Roboto-Regular',
    // medium: 'BreeSerif-Regular',
    // semiBold: 'BreeSerif-Regular',
    // bold: 'BreeSerif-Regular',
  },
  three: {
    // regular: 'SF-UI-Display-Regular',
    // medium: 'Roboto-Medium',
    // semiBold: 'Roboto-Medium',
    // bold: 'Roboto-Bold',
  },
};
