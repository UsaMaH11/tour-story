import 'react-native-gesture-handler';
import React from 'react';
import {  StyleSheet } from 'react-native';
import AppNavigation from './src/Navigation';
import TourGuidePackages from './src/screens/TourGuidesPackages'




export default function App() {
  return ( 
        <AppNavigation/>
        // <ContactUs/>
        // <TourGuidePackages/>
       
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
